---
name: Cyber Command Dashboard
colors:
  surface: '#f8f9ff'
  surface-dim: '#d4dae7'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e7eefb'
  surface-container-high: '#e2e8f5'
  surface-container-highest: '#dce3f0'
  on-surface: '#151c25'
  on-surface-variant: '#444651'
  inverse-surface: '#2a313b'
  inverse-on-surface: '#eaf1fe'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#4b1c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e2c00'
  on-tertiary-container: '#f39461'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#773205'
  background: '#f8f9ff'
  on-background: '#151c25'
  surface-variant: '#dce3f0'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  mono-data:
    fontFamily: monospace
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  margin-desktop: 40px
  margin-mobile: 16px
---

## Brand & Style
The design system focuses on the high-stakes environment of a Security Operations Center (SOC). It prioritizes clarity, rapid information processing, and a sense of institutional stability. The brand personality is vigilant, technical, and precise, designed to minimize cognitive load while maximizing the visibility of critical network threats.

The aesthetic follows a **Corporate / Modern** style with elements of **Minimalism**. It utilizes a systematic approach to density, ensuring that vast amounts of network data remain legible and actionable. The interface evokes trust through a structured grid, professional color usage, and clean, functional transitions.

## Colors
The palette is rooted in deep blues to establish authority and trust. **Deep Blue (#1E3A8A)** serves as the primary brand anchor for headers and primary navigation. **Bright Blue (#3B82F6)** is the functional primary, used for active states, primary buttons, and the "Internet" status indicator.

A semantic color system is strictly enforced for threat detection and network categorization:
- **Red/Orange/Green:** Reserved exclusively for risk assessment and system health.
- **Purple:** Specifically identifies internal network (Intranet) traffic to distinguish it from the broader blue "Internet" traffic.
- **Grays:** Used for secondary text, borders, and subtle background layering to maintain a clean hierarchy.

## Typography
This design system utilizes **Inter** for all UI elements to ensure maximum legibility across high-density data tables and dashboards. The typographic scale is optimized for information density. 

- **Headlines:** Used for section titles and high-level metric summaries. 
- **Labels:** Set in uppercase or semi-bold for metadata and category tags to differentiate them from interactive body text.
- **Monospaced Data:** IP addresses, hash values, and system logs should utilize a monospaced font stack for alignment and character distinction.
- **Mobile:** On small screens, `display-lg` scales down to 28px to maintain visual balance.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a 12-column structure for desktop. 

- **Desktop (1440px+):** 12 columns, 20px gutters, 40px outer margins.
- **Tablet (768px - 1439px):** 8 columns, 16px gutters, 24px outer margins.
- **Mobile (< 767px):** 4 columns, 12px gutters, 16px outer margins. Cards stack vertically.

The spacing system is built on a 4px base unit. Consistent use of `md (16px)` for internal card padding and `lg (24px)` for component separation ensures a professional, breathable rhythm despite the data-heavy nature of the application.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. This design system avoids heavy shadows to maintain a clean, "scientific" look.

- **Level 0 (Background):** The base layer uses `#F3F4F6` (Gray 100) to provide a neutral canvas.
- **Level 1 (Cards/Surface):** Main content containers are solid `#FFFFFF` with a very soft, 10% opacity blue-tinted shadow (0px 2px 4px rgba(30, 58, 138, 0.05)).
- **Level 2 (Popovers/Tooltips):** Floating elements use a more pronounced shadow (0px 8px 16px rgba(30, 58, 138, 0.1)) and a 1px border of `#E5E7EB`.
- **Level 3 (Modals):** Centered surfaces with a dimming backdrop (Gray 900 at 40% opacity).

## Shapes
The design system uses a **Rounded** shape language to soften the technical nature of cybersecurity data and make the UI feel approachable. 

- **Small Components (Buttons, Inputs):** 0.5rem (8px) corner radius.
- **Medium Components (Cards, Modals):** 1rem (16px) corner radius.
- **Status Badges:** Pill-shaped (fully rounded) to differentiate them from clickable buttons or structural containers.

## Components

### Buttons & Inputs
Buttons feature a solid fill for primary actions and a 1px border for secondary actions. Input fields use a white background with a Gray 300 border, turning Bright Blue (#3B82F6) on focus with a subtle outer glow.

### Status Badges
Badges are pill-shaped and use a high-contrast background with white text or a 10% opacity background with saturated text of the same hue for a more modern "tag" look. 
- **High Risk:** Red background, white bold text.
- **Internet:** Blue background, white bold text.

### Cards
Cards are the primary organizational unit. They must include a consistent header with a title (`headline-sm`) and optional action icons. Internal padding is strictly 16px or 24px depending on data density.

### Data Visualizations
Charts should utilize the primary and status color palette. Lines and bars should have slightly rounded caps. Avoid gradients in charts to maintain data integrity and clear reading of values.

### Lists & Tables
Tables use alternating row stripes in Gray 50 or simple 1px horizontal dividers. Cell content should be vertically centered, with a dedicated column for status badges on the far right or left to allow for quick scanning.