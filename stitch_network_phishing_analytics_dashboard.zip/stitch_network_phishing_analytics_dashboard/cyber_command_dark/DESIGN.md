---
name: Cyber Command Dark
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#ffb786'
  on-tertiary: '#502400'
  tertiary-container: '#df7412'
  on-tertiary-container: '#461f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

This design system is engineered for high-stakes Security Operations Center (SOC) environments where cognitive load management and rapid data interpretation are critical. The brand personality is authoritative, technical, and vigilant, utilizing a **Modern Corporate** style infused with **Minimalist** efficiency. 

The interface prioritizes information density without sacrificing clarity. It avoids unnecessary decorative elements, favoring a "heads-up display" (HUD) aesthetic that feels futuristic yet grounded in professional reliability. The emotional response is one of calm control and absolute precision, ensuring operators can identify anomalies instantly within complex datasets.

## Colors

The palette is optimized for low-light environments to reduce eye strain during long shifts. 
- **Primary Surfaces:** Utilize a deep navy-charcoal base (#0f172a) to provide a recessive background that makes active content pop.
- **Containers:** Elevated UI elements use a lighter navy (#1e293b), creating a clear visual hierarchy through tonal layering rather than heavy shadows.
- **Accents:** A professional blue (#3b82f6) is used for primary actions and focus states, ensuring high visibility against the dark backdrop.
- **Semantic Logic:** A strict traffic-light system is used for risk assessment: Red (High/Critical), Amber (Medium/Warning), and Emerald (Low/Safe). These colors should be used sparingly to ensure they retain their "alert" value.

## Typography

The typography system leverages **Geist** for its exceptional legibility and technical feel in the UI, while **JetBrains Mono** is reserved for data-heavy labels, timestamps, and IP addresses to reinforce the developer-centric, precise nature of the tool.

- **Scale:** Use `label-md` and `label-sm` for all telemetry data and system logs.
- **Weight:** Reserve 600+ weights for section headings to maintain clear scannability.
- **Readability:** Body text uses a slightly increased line height (1.5x) to ensure long-form log entries remain readable.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a strict 4px baseline rhythm. 
- **Grid:** A 12-column system is used for desktop views. Dashboard widgets typically span 3, 4, 6, or 12 columns depending on data complexity.
- **Dashboards:** Use a "Masonry-lite" approach for widgets where vertical height is determined by content, but horizontal alignment is strictly locked to columns.
- **Mobile Adaption:** At the 768px breakpoint, the layout collapses to a single column. Horizontal padding is reduced from 32px to 16px to maximize data real estate on smaller screens.

## Elevation & Depth

Depth in this system is achieved through **Tonal Layers** and **Low-Contrast Outlines**. Avoid heavy, fuzzy shadows which can look muddy on deep charcoal backgrounds.

- **Level 0 (Base):** #0f172a. Used for the main application background.
- **Level 1 (Card/Container):** #1e293b. Used for dashboard widgets and sidebar navigation.
- **Level 2 (Popovers/Modals):** #334155. These surfaces use a subtle 1px border (#475569) to distinguish themselves from the background.
- **Stroke Logic:** All interactive containers feature a subtle 1px border with 10-15% opacity white to define boundaries without adding visual noise.

## Shapes

The design system uses a **Soft** shape language. 
- **Standard Radius:** 4px (0.25rem) for buttons, inputs, and small widgets.
- **Large Radius:** 8px (0.5rem) for main dashboard cards and container modules.
- **System Logic:** Sharp corners are avoided to keep the interface feeling modern and accessible, but the radius is kept minimal to maintain a professional, "engineered" aesthetic.

## Components

### Buttons
- **Primary:** Solid #3b82f6 with #f8fafc text. No gradient.
- **Secondary:** Ghost style with a 1px border (#475569) and #f8fafc text.
- **Danger:** Solid #ef4444 for destructive actions only.

### Input Fields
- **Default:** Background #1e293b, border 1px solid #334155, text #f8fafc.
- **Focus State:** Border changes to #3b82f6 with a subtle outer glow (2px blur).

### Chips & Badges
- **Status Badges:** Use a "tinted" style—semi-transparent background of the semantic color (e.g., 20% opacity Red-500) with solid semantic color text. This ensures high legibility in dark mode.

### Data Tables
- **Rows:** Alternate row striping is not used. Instead, use thin 1px horizontal dividers (#1e293b).
- **Hover State:** Row background changes to #1e293b for clear selection tracking.

### Cards / Widgets
- **Header:** Cards should have a distinct header area with a bottom border (#334155) to separate the title and actions from the data visualization.